#pragma once

#include <string>
#include <vector>

#ifndef HURDLESTATE_H
#define HURDLESTATE_H

class HurdleState {
 public:
  //=================== YOUR CODE HERE ===================
  // TODO: Add the constructor(s), accessors, mutators,
  // and any other member function you may need here.
  //======================================================
  HurdleState(const std::string& answer);

 private:
  //=================== YOUR CODE HERE ===================
  // TODO: Add any member variables you need here to store
  // the state of the game. What information needs to be
  // stored to fully represent the game state at a single
  // point in time?
  //======================================================
};

#endif  // HURDLESTATE_H